import 'dart:async';

import 'package:firebase_database/firebase_database.dart';

import 'DataModel.dart';

class DatabaseService{
  final DatabaseReference _database=FirebaseDatabase.instance.ref().child("task");

  Future<void> addTask(Task task)async{
  await _database.child(task.id.toString()).set(task.toJson());
  }

  Future<void> updateTask(String id,Task task)async{
    await _database.child(task.id.toString()).update(task.toJson());
  }

  Future<void> removeTask(Task task)async{
    await _database.child(task.id.toString()).remove();
  }

  DatabaseReference getTasks(){
    return _database;
  }
}