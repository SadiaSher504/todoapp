import 'dart:convert';

class Task {
  final int id;
  final String title;
  final String description;
  bool isCompleted=false;
  Task({
    required this.id,
    required this.title,
    required this.description,
    required this.isCompleted,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'description': description,
    'isCompleted': isCompleted ? 1 : 0,
  };

  factory Task.fromJson(var json) => Task
    (
    id: json['id'],
    title: json['title'],
    description: json['description'],
    isCompleted: json['isCompleted']==1,
  );
  String toJsonString() => json.encode(toJson());
  factory Task.fromJsonString(String jsonString) => Task.fromJson(json.decode(jsonString));
}