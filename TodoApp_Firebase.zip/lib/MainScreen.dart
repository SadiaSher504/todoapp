import 'package:flutter/material.dart';
import 'DataModel.dart';
import 'DatabaseService.dart';

class Studentscreen extends StatefulWidget {
  const Studentscreen({super.key});

  @override
  State<Studentscreen> createState() => _StudentscreenState();
}

class _StudentscreenState extends State<Studentscreen> {

  // Instance of DatabaseService to interact with the database
  final DatabaseService _databaseService = DatabaseService();

  // List to store tasks and search tasks
  List<Task> _task=[];
  List<Task> SearchTasks = [];
  bool _isLoading = true;

  final titleController = TextEditingController();
  final descriptionController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _fetchTasks();
  }

  // function to fetch/retrive data from realtime database
  Future<void> _fetchTasks() async {
    _databaseService.getTasks().onValue.listen((event) {
       List<Task> task=[];
      final data = event.snapshot.value;
      if(data != null && data is Map)
        task = (data.values as Iterable)
            .where((element) => element != null)
            .map((e) => Task.fromJson(Map<String, dynamic>.from(e)))
            .toList();

      setState(() {
        _task = task;
        SearchTasks=task;
        _isLoading = false;
      });
    });
  }

  void clearInputField(){
    titleController.clear();
    descriptionController.clear();
  }

  //function to add task
  void _addTask(){
    final task=Task(
        id: DateTime.now().microsecondsSinceEpoch,
        title:titleController.text,
        description: descriptionController.text,
        isCompleted: false);
    _databaseService.addTask(task);
    _fetchTasks();
    clearInputField();
  }


  //function to edit/update task
  void _editTask(Task task) {
    final updatedTask = Task(
        id: task.id,
        title: titleController.text,
        description: descriptionController.text,
        isCompleted:task.isCompleted);
    _databaseService.updateTask(task.id.toString(), updatedTask);
    _fetchTasks();
    clearInputField();
  }


  //function to remove/delete task
  void _removeTask(Task task){
    _databaseService.removeTask(task);
    _fetchTasks();
    clearInputField();
  }

  // dialog appears when user click on add button
  void _AddTaskDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            'Add New Task',
            style: TextStyle(
              color: Colors.pink.shade700,
              fontWeight: FontWeight.bold,
            ),
          ),
          backgroundColor: Colors.pink.shade50, // Light Pink background
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              TextField(
                controller: titleController,
                decoration: InputDecoration(
                  labelText: 'Title',
                  labelStyle: TextStyle(color: Colors.pink.shade700),
                ),
              ),
              TextField(
                controller: descriptionController,
                decoration: InputDecoration(
                  labelText: 'Description',
                  labelStyle: TextStyle(color: Colors.pink.shade700),
                ),
              ),
            ],
          ),
          actions: <Widget>[
            TextButton(
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all(Colors.pink.shade700),
              ),
              child: Text(
                'Cancel',
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
              ),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all(Colors.pink.shade700),
              ),
              child: Text(
                'Add',
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
              ),
              onPressed: _addTask,
            ),
          ],
        );
      },
    );
  }

  // dialog appears when user click on delete button
  void deleteTaskDialog(Task task) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            'Delete Task',
            style: TextStyle(
              color: Colors.red.shade700,
              fontWeight: FontWeight.bold,
            ),
          ),
          backgroundColor: Colors.red.shade50, // Light Red background
          content: Text(
            'Are you sure you want to delete this task?',
            style: TextStyle(color: Colors.black87),
          ),
          actions: [
            TextButton(
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all(Colors.pink.shade700),
              ),
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text(
                'No',
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
              ),
            ),
            TextButton(
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all(Colors.pink.shade700),
              ),
              onPressed: () {
                _removeTask(task);
                Navigator.of(context).pop();
              },
              child: Text(
                'Yes',
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
              ),
            ),
          ],
        );
      },
    );
  }

  // dialog appears when user click on edit button
  void _editTaskDialog(Task task) {
    titleController.text = task.title;
    descriptionController.text = task.description;
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            'Edit Task',
            style: TextStyle(
              color: Colors.pink.shade700,
              fontWeight: FontWeight.bold,
            ),
          ),
          backgroundColor: Colors.pink.shade50, // Light Pink background
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              TextField(
                controller: titleController,
                decoration: InputDecoration(
                  labelText: 'Title',
                  labelStyle: TextStyle(color: Colors.pink.shade700),

                ),
              ),
              TextField(
                controller: descriptionController,
                decoration: InputDecoration(
                  labelText: 'Description',
                  labelStyle: TextStyle(color: Colors.pink.shade700),

                ),
              ),
            ],
          ),
          actions: <Widget>[
            TextButton(
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all(Colors.pink.shade700),
              ),
              child: Text(
                'Cancel',
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
              ),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all(Colors.pink.shade700),
              ),
              child: Text(
                'Save',
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
              ),
              onPressed: () {
                _editTask(task);
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }


  void searchTask(String enteredKeyword) {
    List<Task> results = [];
    if (enteredKeyword.isEmpty)
    {
      results = _task;
    }
    else
    {
      results = _task.where((task) => task.title.toLowerCase().contains(enteredKeyword.toLowerCase())
      ).toList();
    }

    setState(() {
      SearchTasks = results;
    });
  }

  void showDetail(Task task) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.white,  // Background color of the dialog
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
          title: Center(
            child: Text(
              'Task Details',
              style: TextStyle(
                color: Colors.pink.shade700,  // Title color
                fontWeight: FontWeight.bold,
                fontSize: 30,
              ),
            ),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                margin: EdgeInsets.only(bottom: 20),
                child: Center(
                  child: Text(
                    task.title,
                    style: TextStyle(
                      color: Colors.black,  // Title text color
                      fontWeight: FontWeight.bold,
                      fontSize: 25,
                    ),
                  ),
                ),
              ),
              Container(
                margin: EdgeInsets.only(bottom: 20),
                child: Text(
                  task.description,
                  style: TextStyle(
                    color: Colors.grey[800],  // Description text color
                    fontWeight: FontWeight.normal,
                    fontSize: 18,
                  ),
                ),
              ),
              Container(
                margin: EdgeInsets.only(bottom: 20),
                child: Text(
                  'Status: ${task.isCompleted ? "Completed" : "Incomplete"}',
                  style: TextStyle(
                    color: task.isCompleted ? Colors.green : Colors.red,  // Green for completed, red for incomplete
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                  ),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all(Colors.pink.shade700),
              ),
              child: Text(
                'Close',
                style: TextStyle(
                  color: Colors.white,  // Text color of the button
                  fontWeight: FontWeight.bold,
                ),
              ),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }


  @override
  Widget build(BuildContext context) {
    return
      Scaffold(
      appBar: AppBar(title: Text('Firebase',style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 30),),
        backgroundColor: Colors.pink.shade700,
        centerTitle: true,
      ),
      body:
      _isLoading
          ? Center(child: CircularProgressIndicator())
          :
      Container(
        child: Column(
          children: [
            SizedBox(height: 15,),
            Padding(
              padding: const EdgeInsets.all(20.0),
              child:
              TextField(decoration:
              InputDecoration(suffixIcon: Icon(Icons.search),
                  label: Text('Search',style: TextStyle(fontSize: 20,color: Colors.pinkAccent),),
                  labelStyle: TextStyle(fontSize: 20, color: Colors.pink.shade700),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30),
                    borderSide: BorderSide(color: Colors.pink.shade700),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30),
                    borderSide: BorderSide(color: Colors.pink.shade700, width: 2),
                  ),
              ),
                onChanged: (value)
                {
                  searchTask(value);
                },
              ),
            ),
            SizedBox(height: 20,),
            Expanded(
              child: ListView.builder(
                itemCount: SearchTasks.length,
                itemBuilder: (context, index) {
                  final task = SearchTasks[index];
                  return Padding(
                    padding: const EdgeInsets.all(18.0),
                    child: ListTile(
                      title: Text(
                        task.title,
                        style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 25),),
                      subtitle: Text(
                          task.isCompleted ? 'Completed':'Not Completed',
                          style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 15)
                      ),

                      onTap:(){
                        showDetail(task);
                      },

                      leading: Checkbox(
                        value: task.isCompleted,
                        onChanged:(value) async {
                          setState(() {
                            task.isCompleted=value ??false;
                          });
                          await _databaseService.updateTask(task.id.toString(), task);
                        },
                       side: BorderSide(width: 2,color: Colors.white),
                        checkColor: Colors.pink.shade700,
                        activeColor: Colors.white,
                      ),

                      trailing:
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: Icon(Icons.edit, color: Colors.white),
                            onPressed: () {
                              _editTaskDialog(task);
                            },
                          ),
                          IconButton(
                              icon: Icon(Icons.delete,color: Colors.black,),
                              onPressed:(){
                                deleteTaskDialog(task);}
                          ),
                        ],
                      ),

                      tileColor: Colors.pinkAccent,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      contentPadding: EdgeInsets.all(10),

                    ),
                  );
                },
              ),
            ),


            // button/icon to add task
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(60),
                child: Container(
                  width: 50,
                  height: 50,
                  color: Colors.pink.shade700,
                    child: Center(
                      child: IconButton(icon:
                      Icon(Icons.add,color: Colors.white,size: 35,),
                        onPressed: _AddTaskDialog, ),
                    ),
                ),
              ),
            )
          ],
        ),
      ),

    );
  }
}
